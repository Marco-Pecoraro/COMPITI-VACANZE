const WORDS_URL =
  "https://raw.githubusercontent.com/napolux/paroleitaliane/master/paroleitaliane/1000_parole_italiane_comuni.txt";

const getWords = ((url) =>
  new Promise((resolve, reject) => {
    fetch(url)
      .then((res) => res.text())
      .then((text) => resolve(text.split("\n")))
      .catch((err) => reject(err));
  }))(WORDS_URL);

window.onload = load;

var words;
async function load() {
  try {
    words = await getWords;
    runGame(getWord(words));
  } catch (err) {
    alert("Si è verificato un problema, ricarica la pagina");
  }
}

function getWord(words) {
  let word = "";
  do {
    word = words[Math.floor(Math.random() * words.length)];
  } while (word.length <= 4);
  return word;
}

var guesses = 0,
  first = 1,
  newGame = 0;
const $ = document.querySelector.bind(document);
const $$ = document.querySelectorAll.bind(document);

function runGame(secretWord) {
  console.log("secret word is " + secretWord);
  secretWord = secretWord.toUpperCase();
  $("#solution").textContent =
    "*".repeat(secretWord.length) + " (nuova parola generata)";

  function checkAnswer(user_answer) {
    let len = user_answer.length;
    if (len == secretWord.length) {
      let res = 1;
      for (let i = 0; i < user_answer.length; ++i)
        res &= user_answer[i] == secretWord[i];
      return res;
    }
    if (len == 1) {
      let res = "";
      for (let ch of secretWord) {
        if (ch == user_answer) res += ch;
        else res += "*";
      }
      return res;
    }
    return 0;
  }

  function merge(s1, s2) {
    let res = "";
    for (let i = 0; i < s1.length; ++i) {
      if (s1[i] != "*") res += s1[i];
      else if (s2[i] != "*") res += s2[i];
      else res += "*";
    }
    return res;
  }

  $("form").onsubmit = (e) => {
    e.preventDefault();
    if (newGame) {
      reset();
      runGame(getWord(words));
      return;
    }
    const input = $('form input[type="text"]');
    const val = input.value.trim().toUpperCase();
    input.value = null;

    if (val.length != 1 && val.length != secretWord.length) {
      alert(
        "La tua risposta deve avere 1 oppure " +
          secretWord.length +
          " caratteri."
      );
      return;
    }

    let check = checkAnswer(val);
    if (typeof check === "string") {
      const a = check.replaceAll("*", "");
      console.log(a);
      if (check.replaceAll("*", "").length === 0) ++guesses;
      else {
        let final = merge(
          check,
          first === 1
            ? "*".repeat(secretWord.length)
            : $("#solution").textContent
        );
        $("#solution").textContent = final;
        if (final.replaceAll("*", "").length == final.length) {
          alert("Hai vinto");
          endGame();
        }
      }
    } else if (check === 1) {
      alert("Hai vinto");
      $("#solution").textContent = val;
      endGame();
    } else ++guesses;

    first = 0;

    $("img").src = `hangman/${guesses + 1}.png`;

    if (guesses == 6) {
      endGame();
      setTimeout(() => {
        alert("Hai perso, la parola era " + secretWord);
      }, 100);
    }
  };
}

function endGame() {
  newGame = 1;
  $("button").textContent = "Nuova partita";
  $("button").focus();
}

function reset() {
  guesses = 0;
  first = 1;
  newGame = 0;
  $("button").textContent = "Conferma";
  $("#solution").textContent = "*****";
  $("img").src = "hangman/1.png";
}

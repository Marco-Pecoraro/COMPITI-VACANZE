let turn = 0, cnt = 0;
    const squarees = document.querySelectorAll('.square');

    const changeTurn = () => turn ^= 1;
    const getSymbol = (turn) => turn ? 'X' : 'O';

    const WIN_CONDITIONS = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6]
    ];

    const checkWin = () => {
      let tris = 0;
      for (const [a, b, c] of WIN_CONDITIONS) {
        tris |= (
          squarees[a].textContent &&
          squarees[a].textContent === squarees[b].textContent &&
          squarees[b].textContent === squarees[c].textContent
        );
      }
      return tris;
    }

    function reset() {
      squarees.forEach(square => square.textContent = null);
      cnt = turn = 0;
    }

    squarees.forEach((square, idx) => {
      square.onclick = function () {
        if (this.textContent) return;
        this.textContent = getSymbol(changeTurn());
        if (checkWin()) {
          setTimeout(() => {
            alert(getSymbol(turn) + " vince");
            reset();
          }, 100);
        }
        if (++cnt == 9) {
          setTimeout(() => {
            alert("pareggio");
            reset();
          }, 100);
        }
      }
    });